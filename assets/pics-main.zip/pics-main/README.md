Hello everyone,

This is my first React app.

This is a simple app that brings up 10 images from an object you type in.
