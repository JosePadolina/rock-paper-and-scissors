import axios from "axios";

export default axios.create({
  baseURL: "https://api.unsplash.com",
  headers: {
    Authorization: "Client-ID DmeYWEKkl4Kmc7_AG2UsEwlc9rsAaI1t_Y7jjqfsAEI",
  },
});
